Attach this script directly to your AI Behaviors agent and it should now receive damage into the GotHit state.

Report any issues to nathanwarden@icloud.com

Thanks!
