﻿using AIBehavior;
using UnityEngine;
using System.Collections;

// Add this script directly to your AI Behaviors agent

public class Hit_By_UFPS : MonoBehaviour
{
	AIBehaviors ai;


	void Awake()
	{
		ai = GetComponent<AIBehaviors>();
	}
	
	
	public void Damage (float damage)
	{
		ai.GotHit(damage);
	}


	public void Damage (vp_DamageInfo damageInfo)
	{
		ai.GotHit(damageInfo.Damage);
	}
}
